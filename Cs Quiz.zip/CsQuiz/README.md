# CsQuiz
This is Programming Languages Quiz App.
This App is created using Sqlite Database.
This App Contain mcqs of different topics of programming languages.
